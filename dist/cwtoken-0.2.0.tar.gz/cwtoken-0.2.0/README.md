\## Available Functions



\### fetch(clubcode, token, request, timeout=10)

Handles access token generation, makes request, returns data as a Pandas DataFrame.



\### get\_access\_token(clubcode, token, timeout=10)

Returns just the access token for manual use.



\### test\_connection()

Pings the API server. Returns True if reachable.

